package com.estehangettt.tivora

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay

private tailrec fun Context.activity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.activity()
    else -> null
}

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(c: Channel, fav: Boolean, onFav: () -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var loading by remember { mutableStateOf(true) }
    var err by remember { mutableStateOf<String?>(null) }
    var pw by remember { mutableStateOf(true) }
    var ui by remember { mutableStateOf(true) }
    var attempt by remember { mutableIntStateOf(0) }

    val exo = remember(c, attempt) {
        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(15000)
            .setUserAgent(c.ua ?: "Mozilla/5.0 (Linux; Android 13) Tivora/1.0")
        c.referrer?.let { http.setDefaultRequestProperties(mapOf("Referer" to it)) }
        ExoPlayer.Builder(ctx)
            .setMediaSourceFactory(DefaultMediaSourceFactory(http))
            .build().apply {
                setMediaItem(MediaItem.fromUri(c.url))
                prepare()
                playWhenReady = true
            }
    }

    DisposableEffect(exo) {
        val l = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                loading = state == Player.STATE_BUFFERING
                if (state == Player.STATE_READY) err = null
            }
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) { pw = playWhenReady }
            override fun onPlayerError(error: PlaybackException) {
                loading = false
                err = "Channel ini tidak bisa diputar"
            }
        }
        exo.addListener(l)
        onDispose { exo.removeListener(l); exo.release() }
    }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner, exo) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_STOP) exo.pause() }
        owner.lifecycle.addObserver(o)
        onDispose { owner.lifecycle.removeObserver(o) }
    }

    DisposableEffect(Unit) {
        val a = ctx.activity()
        val ctl = a?.let { WindowCompat.getInsetsController(it.window, it.window.decorView) }
        a?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        ctl?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        ctl?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose {
            a?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            ctl?.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    LaunchedEffect(err) { if (err != null) ui = true }
    LaunchedEffect(ui, pw, err) {
        if (ui && pw && err == null) {
            delay(3500)
            ui = false
        }
    }

    Box(
        Modifier.fillMaxSize().background(Color.Black)
            .pointerInput(Unit) { detectTapGestures { ui = !ui } }
    ) {
        AndroidView(
            factory = { x ->
                PlayerView(x).apply {
                    useController = false
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    keepScreenOn = true
                    player = exo
                }
            },
            update = { it.player = exo },
            modifier = Modifier.fillMaxSize()
        )
        if (loading && err == null) {
            CircularProgressIndicator(Modifier.align(Alignment.Center), color = Color.White, strokeWidth = 3.dp)
        }
        err?.let { msg ->
            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                T(msg, 18, FontWeight.SemiBold, align = TextAlign.Center)
                T("Mungkin sedang offline atau diblokir di wilayahmu.", 14, c = Gray, mod = Modifier.padding(top = 4.dp, bottom = 16.dp), align = TextAlign.Center)
                PillButton("Coba lagi") { err = null; loading = true; attempt++ }
            }
        }
        AnimatedVisibility(ui, enter = fadeIn(), exit = fadeOut()) {
            Box(Modifier.fillMaxSize()) {
                Box(
                    Modifier.fillMaxWidth().height(110.dp)
                        .background(Brush.verticalGradient(listOf(Color(0xB3000000), Color.Transparent)))
                )
                Row(
                    Modifier.fillMaxWidth().statusBarsPadding().displayCutoutPadding().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    GlassCircle(44, onClose) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, null, tint = Color.White, modifier = Modifier.size(24.dp))
                    }
                    Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                        T(c.name, 18, FontWeight.Bold, max = 1)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(7.dp).clip(CircleShape).background(Pink))
                            T("LIVE", 11, FontWeight.Bold, Color.White, Modifier.padding(start = 5.dp), sp = 1f)
                        }
                    }
                    GlassCircle(44, onFav) {
                        Icon(
                            if (fav) Icons.Rounded.Favorite else Icons.Outlined.FavoriteBorder, null,
                            tint = if (fav) Pink else Color.White, modifier = Modifier.size(22.dp)
                        )
                    }
                }
                if (err == null) {
                    Box(Modifier.align(Alignment.Center)) {
                        GlassCircle(76, { exo.playWhenReady = !exo.playWhenReady }) {
                            if (pw) PauseGlyph() else Icon(Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(44.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PauseGlyph() {
    Canvas(Modifier.size(28.dp)) {
        val r = CornerRadius(4.dp.toPx())
        val bw = size.width * 0.26f
        drawRoundRect(Color.White, Offset(size.width * 0.14f, 0f), Size(bw, size.height), r)
        drawRoundRect(Color.White, Offset(size.width * 0.60f, 0f), Size(bw, size.height), r)
    }
}
