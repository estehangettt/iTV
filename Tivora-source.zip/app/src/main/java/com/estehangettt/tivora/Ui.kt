package com.estehangettt.tivora

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.hazeEffect
import dev.chrisbanes.haze.hazeSource
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

val Bg = Color.Black
val Blue = Color(0xFF0A84FF)
val Gray = Color(0xFF8E8E93)
val Pink = Color(0xFFFF375F)

@Composable
fun T(
    s: String, size: Int = 15, w: FontWeight = FontWeight.Normal, c: Color = Color.White,
    mod: Modifier = Modifier, max: Int = Int.MAX_VALUE, sp: Float = 0f, align: TextAlign? = null
) = Text(
    s, modifier = mod, color = c, fontSize = size.sp, fontWeight = w, maxLines = max,
    overflow = TextOverflow.Ellipsis, letterSpacing = sp.sp, textAlign = align
)

/** iOS-style spring "press" feedback. */
fun Modifier.pressable(onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) 0.95f else 1f, spring(dampingRatio = 0.55f, stiffness = 500f), label = "press")
    this.graphicsLayer { scaleX = s; scaleY = s }
        .clickable(interactionSource = src, indication = null, onClick = onClick)
}

@Composable
fun PillButton(text: String, play: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier.pressable(onClick).clip(RoundedCornerShape(50)).background(Color(0xEBFFFFFF))
            .padding(horizontal = 22.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (play) Icon(Icons.Rounded.PlayArrow, null, tint = Color.Black, modifier = Modifier.size(22.dp))
        T(text, 16, FontWeight.Bold, Color.Black)
    }
}

@Composable
fun GlassCircle(size: Int = 44, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier.size(size.dp).pressable(onClick).clip(CircleShape)
            .background(Color(0x40FFFFFF)).border(0.6.dp, Color(0x33FFFFFF), CircleShape),
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
fun TivoraApp(vm: VM) {
    var splash by remember { mutableStateOf(true) }
    var tab by remember { mutableIntStateOf(0) }
    var show by remember { mutableStateOf(false) }
    var current by remember { mutableStateOf<Channel?>(null) }
    val haze = remember { HazeState() }
    val play: (Channel) -> Unit = { current = it; show = true }
    BackHandler(show) { show = false }

    Box(Modifier.fillMaxSize().background(Bg)) {
        Box(Modifier.fillMaxSize().hazeSource(haze)) {
            Crossfade(tab, label = "tab") { t ->
                when (t) {
                    0 -> HomeScreen(vm, play)
                    1 -> SearchScreen(vm, play)
                    else -> FavScreen(vm, play)
                }
            }
        }
        TabBar(tab, { tab = it }, haze, Modifier.align(Alignment.BottomCenter))
        AnimatedVisibility(
            visible = show,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
        ) {
            current?.let { c ->
                PlayerScreen(c, c.url in vm.favs, { vm.toggleFav(c.url) }) { show = false }
            }
        }
        if (splash) Splash { splash = false }
    }
}

@Composable
fun Splash(onDone: () -> Unit) {
    val sc = remember { Animatable(0.7f) }
    val fi = remember { Animatable(0f) }
    val fo = remember { Animatable(1f) }
    LaunchedEffect(Unit) {
        launch { sc.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = 120f)) }
        fi.animateTo(1f, tween(550))
        delay(800)
        fo.animateTo(0f, tween(450))
        onDone()
    }
    Box(
        Modifier.fillMaxSize().graphicsLayer { this.alpha = fo.value }.background(Bg),
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier.size(340.dp).graphicsLayer { this.alpha = fi.value }
                .background(Brush.radialGradient(listOf(Blue.copy(alpha = 0.35f), Color.Transparent)))
        )
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier.size(132.dp)
                    .graphicsLayer { scaleX = sc.value; scaleY = sc.value; this.alpha = fi.value }
                    .clip(RoundedCornerShape(30.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF5E5CE6), Blue, Color(0xFF64D2FF))))
            ) {
                Image(painterResource(R.drawable.ic_launcher_fg), null, Modifier.fillMaxSize())
            }
            Spacer(Modifier.height(22.dp))
            T("Tivora", 30, FontWeight.Bold, mod = Modifier.graphicsLayer { this.alpha = fi.value }, sp = 1f)
        }
    }
}

@Composable
fun TabBar(sel: Int, onSel: (Int) -> Unit, haze: HazeState, mod: Modifier) {
    val shape = RoundedCornerShape(34.dp)
    val tabs = listOf("Beranda" to Icons.Rounded.Home, "Cari" to Icons.Rounded.Search, "Favorit" to Icons.Rounded.Favorite)
    Row(
        mod.navigationBarsPadding().padding(bottom = 12.dp).clip(shape)
            .hazeEffect(haze) { blurRadius = 28.dp; noiseFactor = 0.04f }
            .background(Color(0x8C1C1C1E))
            .border(0.6.dp, Color(0x33FFFFFF), shape)
            .padding(6.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        tabs.forEachIndexed { i, (label, icon) ->
            val on = sel == i
            val bg by animateColorAsState(if (on) Color(0x2EFFFFFF) else Color.Transparent, spring(), label = "bg")
            val col by animateColorAsState(if (on) Blue else Gray, spring(), label = "col")
            Column(
                Modifier.clip(RoundedCornerShape(28.dp)).background(bg)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onSel(i) }
                    .padding(horizontal = 24.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(icon, label, tint = col, modifier = Modifier.size(24.dp))
                T(label, 10, FontWeight.Medium, col)
            }
        }
    }
}

@Composable
fun LogoTile(c: Channel, mod: Modifier, radius: Dp = 16.dp) {
    var ok by remember(c.url) { mutableStateOf(false) }
    Box(
        mod.clip(RoundedCornerShape(radius))
            .background(Brush.linearGradient(listOf(Color(0xFFF5F5F7), Color(0xFFD8D8DE))))
            .padding(10.dp),
        contentAlignment = Alignment.Center
    ) {
        if (!ok) T(c.name.take(2).uppercase(), 20, FontWeight.Bold, Gray)
        AsyncImage(
            model = c.logo, contentDescription = null, contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize(), onSuccess = { ok = true }
        )
    }
}

@Composable
fun ChannelCard(c: Channel, onClick: () -> Unit) {
    Column(Modifier.width(184.dp).pressable(onClick)) {
        LogoTile(c, Modifier.fillMaxWidth().aspectRatio(16f / 9f), 18.dp)
        T(c.name, 14, FontWeight.SemiBold, mod = Modifier.padding(top = 8.dp, start = 4.dp), max = 1)
        T(c.group, 12, c = Gray, mod = Modifier.padding(start = 4.dp), max = 1)
    }
}

@Composable
fun ChannelRow(c: Channel, fav: Boolean, onFav: () -> Unit, onPlay: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().pressable(onPlay).padding(horizontal = 20.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        LogoTile(c, Modifier.width(88.dp).aspectRatio(16f / 9f), 12.dp)
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            T(c.name, 16, FontWeight.SemiBold, max = 1)
            T(c.group, 13, c = Gray, max = 1)
        }
        Box(Modifier.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onFav() }.padding(8.dp)) {
            Icon(
                if (fav) Icons.Rounded.Favorite else Icons.Outlined.FavoriteBorder, null,
                tint = if (fav) Pink else Gray, modifier = Modifier.size(24.dp)
            )
        }
    }
}

@Composable
fun Title(text: String) =
    T(text, 34, FontWeight.Bold, mod = Modifier.statusBarsPadding().padding(horizontal = 20.dp, vertical = 14.dp), sp = -0.6f)

@Composable
fun HomeScreen(vm: VM, onPlay: (Channel) -> Unit) {
    when (val s = vm.state) {
        UiState.Loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = Blue) }
        is UiState.Error -> Column(
            Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally
        ) {
            T(s.msg, 16, c = Gray, align = TextAlign.Center)
            Spacer(Modifier.height(18.dp))
            PillButton("Coba lagi") { vm.load(true) }
        }
        is UiState.Ready -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 130.dp)) {
            item { Hero(s.hero, onPlay) { vm.load(true) } }
            items(s.rows) { (title, list) ->
                Column(Modifier.padding(top = 22.dp)) {
                    T(title, 22, FontWeight.Bold, mod = Modifier.padding(horizontal = 20.dp, vertical = 10.dp), sp = -0.4f)
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(list) { ch -> ChannelCard(ch) { onPlay(ch) } }
                    }
                }
            }
        }
    }
}

private fun tint(c: Channel) = Color.hsv(Math.floorMod(c.name.hashCode(), 360).toFloat(), 0.6f, 0.45f)

@Composable
fun Hero(items: List<Channel>, onPlay: (Channel) -> Unit, onRefresh: () -> Unit) {
    if (items.isEmpty()) {
        Spacer(Modifier.statusBarsPadding().height(70.dp))
        return
    }
    val pager = rememberPagerState { items.size }
    LaunchedEffect(items) {
        while (true) {
            delay(5000)
            pager.animateScrollToPage((pager.currentPage + 1) % items.size)
        }
    }
    Box(Modifier.fillMaxWidth().height(460.dp)) {
        HorizontalPager(pager, Modifier.fillMaxSize()) { i ->
            val c = items[i]
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(tint(c), Bg)))) {
                LogoTile(
                    c,
                    Modifier.align(Alignment.Center).offset(y = (-24).dp).width(200.dp).aspectRatio(16f / 9f)
                        .shadow(28.dp, RoundedCornerShape(26.dp)),
                    26.dp
                )
                Box(
                    Modifier.fillMaxSize()
                        .background(Brush.verticalGradient(0.45f to Color.Transparent, 1f to Bg))
                )
                Column(Modifier.align(Alignment.BottomStart).padding(start = 24.dp, end = 24.dp, bottom = 40.dp)) {
                    T("LIVE · ${c.group.uppercase()}", 12, FontWeight.Bold, Blue, sp = 1f)
                    T(c.name, 32, FontWeight.Bold, mod = Modifier.padding(vertical = 6.dp), max = 2, sp = -0.5f)
                    Spacer(Modifier.height(8.dp))
                    PillButton("Tonton", play = true) { onPlay(c) }
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 20.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
        ) {
            T("Tivora", 22, FontWeight.Bold, sp = -0.3f)
            GlassCircle(40, onRefresh) { Icon(Icons.Rounded.Refresh, null, tint = Color.White, modifier = Modifier.size(22.dp)) }
        }
        Row(
            Modifier.align(Alignment.BottomEnd).padding(end = 24.dp, bottom = 22.dp),
            horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically
        ) {
            items.indices.forEach { i ->
                val w by animateDpAsState(if (i == pager.currentPage) 18.dp else 6.dp, spring(), label = "dot")
                Box(
                    Modifier.size(w, 6.dp).clip(CircleShape)
                        .background(if (i == pager.currentPage) Color.White else Color(0x66FFFFFF))
                )
            }
        }
    }
}

@Composable
fun SearchScreen(vm: VM, onPlay: (Channel) -> Unit) {
    var q by remember { mutableStateOf("") }
    val all = (vm.state as? UiState.Ready)?.all.orEmpty()
    val res = remember(q, all) {
        val k = q.trim()
        if (k.length < 2) emptyList() else all.filter { it.name.contains(k, ignoreCase = true) }.take(100)
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 130.dp)) {
        item {
            Column {
                Title("Cari")
                SearchField(q) { q = it }
                Spacer(Modifier.height(10.dp))
            }
        }
        if (q.trim().length >= 2 && res.isEmpty()) {
            item { T("Tidak ada hasil", 16, c = Gray, mod = Modifier.padding(20.dp)) }
        }
        items(res) { c -> ChannelRow(c, c.url in vm.favs, { vm.toggleFav(c.url) }) { onPlay(c) } }
    }
}

@Composable
fun SearchField(q: String, onQ: (String) -> Unit) {
    Row(
        Modifier.padding(horizontal = 20.dp).fillMaxWidth().height(44.dp).clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF1C1C1E)).padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Search, null, tint = Gray, modifier = Modifier.size(20.dp))
        Box(Modifier.weight(1f).padding(horizontal = 8.dp)) {
            if (q.isEmpty()) T("Cari channel", 16, c = Gray)
            BasicTextField(
                value = q, onValueChange = onQ, singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                cursorBrush = SolidColor(Blue), modifier = Modifier.fillMaxWidth()
            )
        }
        if (q.isNotEmpty()) {
            Icon(
                Icons.Rounded.Close, null, tint = Gray,
                modifier = Modifier.size(20.dp)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onQ("") }
            )
        }
    }
}

@Composable
fun FavScreen(vm: VM, onPlay: (Channel) -> Unit) {
    val all = (vm.state as? UiState.Ready)?.all.orEmpty()
    val list = remember(all, vm.favs) { all.filter { it.url in vm.favs } }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 130.dp)) {
        item { Title("Favorit") }
        if (list.isEmpty()) {
            item {
                Column(Modifier.fillMaxWidth().padding(top = 80.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Outlined.FavoriteBorder, null, tint = Gray, modifier = Modifier.size(48.dp))
                    T("Belum ada favorit", 17, FontWeight.SemiBold, mod = Modifier.padding(top = 12.dp))
                    T("Ketuk ikon hati pada channel untuk menyimpannya.", 14, c = Gray, mod = Modifier.padding(top = 4.dp, start = 40.dp, end = 40.dp), align = TextAlign.Center)
                }
            }
        }
        items(list) { c -> ChannelRow(c, true, { vm.toggleFav(c.url) }) { onPlay(c) } }
    }
}
