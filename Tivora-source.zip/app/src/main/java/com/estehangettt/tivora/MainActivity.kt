package com.estehangettt.tivora

import android.graphics.Color as AColor
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val crashFile = File(filesDir, "crash.txt")
        val pending = if (crashFile.exists()) runCatching { crashFile.readText() }.getOrNull() else null
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching { crashFile.writeText(Log.getStackTraceString(e)) }
            prev?.uncaughtException(t, e)
        }
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT)
        )
        setContent {
            var crash by remember { mutableStateOf(pending) }
            val c = crash
            if (c != null) {
                CrashScreen(c) { crashFile.delete(); crash = null }
            } else {
                val vm: VM = viewModel()
                TivoraApp(vm)
            }
        }
    }
}

@Composable
fun CrashScreen(log: String, onContinue: () -> Unit) {
    val clip = LocalClipboardManager.current
    val summary = log.lines()
        .filter { it.startsWith("Caused by") || (it.contains("Exception") && !it.trimStart().startsWith("at ")) || it.contains("Error:") }
        .take(4).joinToString("\n")
    Column(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding().navigationBarsPadding().padding(16.dp)) {
        T("Tivora berhenti tiba-tiba", 20, FontWeight.Bold)
        T("Screenshot layar ini lalu kirim ke developer.", 13, c = Gray, mod = Modifier.padding(vertical = 6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PillButton("Salin") { clip.setText(AnnotatedString(log)) }
            PillButton("Lanjut", onClick = onContinue)
        }
        Box(Modifier.weight(1f).padding(top = 12.dp).verticalScroll(rememberScrollState())) {
            Column {
                Text(summary, color = Color(0xFFFF9F0A), fontSize = 13.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                Text(log.take(4000), color = Color(0xFFAAAAAA), fontSize = 9.sp, lineHeight = 12.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(top = 10.dp))
            }
        }
    }
}
