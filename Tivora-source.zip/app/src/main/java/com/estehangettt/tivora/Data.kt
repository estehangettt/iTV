package com.estehangettt.tivora

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit

data class Channel(
    val name: String,
    val url: String,
    val logo: String?,
    val group: String,
    val isId: Boolean,
    val referrer: String?,
    val ua: String?
)

sealed interface UiState {
    data object Loading : UiState
    data class Error(val msg: String) : UiState
    data class Ready(
        val all: List<Channel>,
        val rows: List<Pair<String, List<Channel>>>,
        val hero: List<Channel>
    ) : UiState
}

object Repo {
    const val PLAYLIST = "https://iptv-org.github.io/iptv/index.m3u"
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()
    private val attrRe = Regex("([\\w-]+)=\"([^\"]*)\"")
    private val tagRe = Regex("\\s*(\\[[^\\]]*\\]|\\(\\d{3,4}[pi]\\))")

    suspend fun load(ctx: Context, force: Boolean): List<Channel> = withContext(Dispatchers.IO) {
        val f = File(ctx.filesDir, "index.m3u")
        val fresh = f.exists() && System.currentTimeMillis() - f.lastModified() < 12 * 3600_000L
        if (force || !fresh) {
            try {
                http.newCall(Request.Builder().url(PLAYLIST).build()).execute().use { r ->
                    if (!r.isSuccessful) error("HTTP ${r.code}")
                    val tmp = File(ctx.filesDir, "index.tmp")
                    r.body!!.byteStream().use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                    tmp.renameTo(f)
                }
            } catch (e: Exception) {
                if (!f.exists()) throw e
            }
        }
        parse(f)
    }

    private fun parse(f: File): List<Channel> {
        val out = ArrayList<Channel>(12000)
        var name = ""
        var logo: String? = null
        var group = "Lainnya"
        var isId = false
        var ref: String? = null
        var ua: String? = null
        var pending = false
        f.bufferedReader().useLines { seq ->
            for (raw in seq) {
                val l = raw.trim()
                if (l.isEmpty()) continue
                if (l.startsWith("#EXTINF")) {
                    val a = attrRe.findAll(l).associate { it.groupValues[1] to it.groupValues[2] }
                    name = l.substringAfterLast(',').replace(tagRe, "").trim()
                    logo = a["tvg-logo"]?.takeIf { it.startsWith("http") }
                    group = a["group-title"]?.substringBefore(';')?.trim()
                        ?.takeIf { it.isNotEmpty() && it != "Undefined" } ?: "Lainnya"
                    isId = a["tvg-id"].orEmpty().substringBefore('@').endsWith(".id")
                    ref = null
                    ua = null
                    pending = true
                } else if (l.startsWith("#EXTVLCOPT:http-referrer=")) {
                    ref = l.substringAfter('=')
                } else if (l.startsWith("#EXTVLCOPT:http-user-agent=")) {
                    ua = l.substringAfter('=')
                } else if (!l.startsWith("#") && pending) {
                    if (name.isNotEmpty()) out.add(Channel(name, l, logo, group, isId, ref, ua))
                    pending = false
                }
            }
        }
        return out.distinctBy { it.name.lowercase() + "|" + it.group }
    }
}

class VM(private val app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("tivora", Context.MODE_PRIVATE)
    var state by mutableStateOf<UiState>(UiState.Loading)
        private set
    var favs by mutableStateOf(prefs.getStringSet("fav", emptySet()).orEmpty().toSet())
        private set

    init { load(false) }

    fun load(force: Boolean) {
        state = UiState.Loading
        viewModelScope.launch {
            state = try {
                val list = Repo.load(app, force)
                withContext(Dispatchers.Default) { build(list) }
            } catch (e: Exception) {
                UiState.Error("Tidak bisa memuat daftar channel.\nPeriksa koneksi internetmu.")
            }
        }
    }

    fun toggleFav(url: String) {
        favs = if (url in favs) favs - url else favs + url
        prefs.edit().putStringSet("fav", favs).apply()
    }

    private fun build(list: List<Channel>): UiState.Ready {
        val byGroup = list.groupBy { it.group }
        val order = listOf(
            "News", "Sports", "Movies", "Entertainment", "Music", "Kids", "Documentary",
            "Animation", "Series", "Comedy", "Lifestyle", "Education", "Culture", "Travel", "Cooking"
        )
        val idList = list.filter { it.isId }
        val rows = buildList<Pair<String, List<Channel>>> {
            if (idList.isNotEmpty()) add("Indonesia" to idList.take(60))
            order.forEach { g -> byGroup[g]?.let { if (it.size >= 5) add(g to it.take(50)) } }
            byGroup.entries
                .filter { it.key !in order && it.key != "Lainnya" && it.value.size >= 5 }
                .sortedByDescending { it.value.size }
                .take(6)
                .forEach { add(it.key to it.value.take(50)) }
        }
        val withLogo = idList.filter { it.logo != null }.ifEmpty { list.filter { it.logo != null } }
        return UiState.Ready(list, rows, withLogo.take(5))
    }
}
